module.exports = {
  testMatch: ["<rootDir>/*.test.js"],
};
